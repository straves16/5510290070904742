export { DiscardChanges } from './discard-changes-dialog'
