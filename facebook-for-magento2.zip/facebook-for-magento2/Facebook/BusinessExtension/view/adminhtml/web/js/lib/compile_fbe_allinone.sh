#!/bin/bash
# Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved

NODE_PATH=. browserify fbe.js > ../fbe_allinone.js
